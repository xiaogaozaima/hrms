create function test_fun(eid in number) return number
  as
  e_sal number;
  begin
    select SAL into e_sal from EMP where EMPNO=eid;
    return e_sal*12;
  end;
/

