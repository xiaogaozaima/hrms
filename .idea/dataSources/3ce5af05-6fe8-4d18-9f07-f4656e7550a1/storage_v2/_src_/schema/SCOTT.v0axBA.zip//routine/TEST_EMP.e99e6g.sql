create procedure test_emp(empid in number,addsal in number,ename out varchar2,esal out number)
  as
  begin
    select ENAME,SAL into ename,esal from EMP where EMPNO=empid;
    dbms_output.put_line(ename||'，原薪资是：'||esal);
    update EMP set SAL=esal+addsal where EMPNO=empid;
    commit ;
    select ENAME,SAL into ename,esal from EMP where EMPNO=empid;
    dbms_output.put_line(ename||'，现薪资是：'||esal);
  end;
/

