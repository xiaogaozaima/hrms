create trigger TEST_TRIGGER
  before update
  on EMP
  declare
    h number;
  begin
    select to_number(to_char(sysdate,'hh24')) into h from dual;
    if h>9 and h<18 then raise_application_error(-20001,'时间不对');
      end if ;
  end;
/

